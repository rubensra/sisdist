from django.apps import AppConfig


class CampominadoConfig(AppConfig):
    name = 'CampoMinado'
